=== comment-add ===
Contributors: Shebin
Tags: 
Requires at least: 1.0
Tested up to: 1.0
License: GPLv2 or later



== Description ==

plugin can be used for 
1.For Form
2.header and footer scripts(can considered as another plugin)
3.we can see the code here for learning add_filter and add_action


Major features include:

* can send the form details to a mail
* can add the form detail to the database
*can add form data to comment and see later

== Installation ==

Upload the comment-add plugin to your blog, Activate it.






= 1.0=
*Release Date - 29 may 2018*

Done the basic backbone for the form

= 1.0.2 =
*Release Date - 29 may 2018*

* Done adding data to comment.
* Done adding form details to Db.


= 1.0.3 =
*Release Date - 30 may 2018*
 
* Fixed a bug in connecting db
* Fixed a bug in comment.
