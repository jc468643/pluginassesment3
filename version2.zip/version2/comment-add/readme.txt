=== comment-add ===
Contributors: Shebin
Tags: 
Requires at least: 1.0
Tested up to: 1.0
License: GPLv2 or later



== Description ==

plugin can be used for 
1.For Form
2.header and footer scripts


Major features include(not done all yet):

* can send the form details to a mail
* can add the form detail to the database
*can add form data to comment and see later

== Installation ==

Upload the comment-add plugin to your blog, Activate it.





= 1.0=
*Release Date - 29 may 2018*

Done the basic backbone for the form

= 1.0.1 =
*Release Date - 29 may 2018*

* Done adding data to comment.
*Done adding form details to Db.
